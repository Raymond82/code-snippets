﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows.Controls;

    /// <summary>
    /// Логика взаимодействия для AddRemoveView.xaml
    /// </summary>
    public partial class AddRemoveView : UserControl
    {
        public AddRemoveView()
        {
            this.InitializeComponent();
        }
    }
}
