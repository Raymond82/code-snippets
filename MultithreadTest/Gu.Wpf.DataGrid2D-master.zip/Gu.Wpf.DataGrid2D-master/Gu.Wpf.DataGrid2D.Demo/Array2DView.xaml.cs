﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for Array2DView.xaml
    /// </summary>
    public partial class Array2DView : UserControl
    {
        public Array2DView()
        {
            this.InitializeComponent();
        }
    }
}
