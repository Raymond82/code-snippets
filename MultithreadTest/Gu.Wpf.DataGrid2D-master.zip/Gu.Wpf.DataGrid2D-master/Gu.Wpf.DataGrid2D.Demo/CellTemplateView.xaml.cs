﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for CellTemplateView.xaml
    /// </summary>
    public partial class CellTemplateView : UserControl
    {
        public CellTemplateView()
        {
            this.InitializeComponent();
        }
    }
}
