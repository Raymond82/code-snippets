﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for JaggedView.xaml
    /// </summary>
    public partial class JaggedView : UserControl
    {
        public JaggedView()
        {
            this.InitializeComponent();
        }
    }
}
