namespace Gu.Wpf.DataGrid2D.Demo
{
    internal static class Ignore
    {
        // ReSharper disable once UnusedParameter.Global
        internal static void IgnoreReturnValue<T>(this T value)
        {
        }
    }
}
