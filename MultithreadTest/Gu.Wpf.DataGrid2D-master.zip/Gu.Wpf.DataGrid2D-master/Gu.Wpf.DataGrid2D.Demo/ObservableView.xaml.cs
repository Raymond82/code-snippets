﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for ObservableView.xaml
    /// </summary>
    public partial class ObservableView : UserControl
    {
        public ObservableView()
        {
            this.InitializeComponent();
        }
    }
}
