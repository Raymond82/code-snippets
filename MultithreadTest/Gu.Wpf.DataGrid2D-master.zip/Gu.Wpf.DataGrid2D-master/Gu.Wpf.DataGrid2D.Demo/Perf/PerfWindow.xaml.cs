﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows;

    /// <summary>
    /// Interaction logic for PerfWindow.xaml
    /// </summary>
    public partial class PerfWindow : Window
    {
        public PerfWindow()
        {
            this.InitializeComponent();
        }
    }
}
