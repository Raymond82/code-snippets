﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for PropertyChangedView.xaml
    /// </summary>
    public partial class PropertyChangedView : UserControl
    {
        public PropertyChangedView()
        {
            this.InitializeComponent();
        }
    }
}
