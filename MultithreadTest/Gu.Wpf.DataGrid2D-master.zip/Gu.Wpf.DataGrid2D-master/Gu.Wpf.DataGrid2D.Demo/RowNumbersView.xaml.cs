﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for RowNumbersView.xaml
    /// </summary>
    public partial class RowNumbersView : UserControl
    {
        public RowNumbersView()
        {
            this.InitializeComponent();
        }
    }
}
