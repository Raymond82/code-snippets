﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for SelectedView.xaml
    /// </summary>
    public partial class SelectedView : UserControl
    {
        public SelectedView()
        {
            this.InitializeComponent();
        }
    }
}
