﻿namespace Gu.Wpf.DataGrid2D.Demo
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for TransposedView.xaml
    /// </summary>
    public partial class TransposedView : UserControl
    {
        public TransposedView()
        {
            this.InitializeComponent();
        }
    }
}
