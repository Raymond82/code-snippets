﻿namespace Gu.Wpf.DataGrid2D.Tests.Views
{
    public partial class Lists2DViewTests
    {
        public class ObservableCollections
        {
        }
    }
}
