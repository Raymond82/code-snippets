﻿namespace Gu.Wpf.DataGrid2D.UiTests
{
    using Gu.Wpf.UiAutomation;

    public static class Info
    {
        public static string ExeFileName { get; } = Application.FindExe("Gu.Wpf.DataGrid2D.Demo.exe");
    }
}